
public interface Guitar
{
	default void play()
	{
		System.out.println("I am playing Guitar.");
	}
}
