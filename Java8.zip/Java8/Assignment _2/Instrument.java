
public class Instrument implements Piano,Guitar{

	@Override
	public void play() {
		System.out.println("Resolving method name ambiguity by overriding the method.");
		System.out.println("I am overridden play().");
	}
	public void playThis()
	{
		System.out.println("Resolving method name ambiguity by using super keyword along with interface.");
		Piano.super.play();
		Guitar.super.play();
	}
	public static void main(String args[])
	{
		Instrument i=new Instrument();
		i.play();
		i.playThis();
	}

}
