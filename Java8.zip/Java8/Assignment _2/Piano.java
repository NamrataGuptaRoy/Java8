
public interface Piano
{
	default void play()
	{
		System.out.println("I am playing Piano.");
	}
}
