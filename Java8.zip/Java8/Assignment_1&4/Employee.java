
public class Employee{
	int id;String name,address;double sal;
	public Employee()
	{
		 id=0;
		 name="";address="";
		 sal=0.0;
	}
	public Employee(int i,String n,String a,double s)
	{
		 id=i;
		 name=n;address=a;
		 sal=s;
	}
	public int getId()
	{
		return id;
	}
	public String getName()
	{
		return name;
	}
	public String getAddress()
	{
		return address;
	}
	public double getSalary()
	{
		return sal;
	}
	public static int compareBySal(Employee e1,Employee e2)
	{
		if(e1.getSalary()>e2.getSalary())return 1;
		else return -1;
	}
	
}
