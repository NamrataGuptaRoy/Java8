import java.util.ArrayList;
import java.util.Collections;

public class EmployeeDetails {

	public static void main(String[] args)
	{
		ArrayList<Employee> list=new ArrayList<Employee>();
		list.add(new Employee(1,"emp1","abc1",22000.00));
		list.add(new Employee(2,"emp2","abc2",20000.00));
		list.add(new Employee(3,"emp3","abc3",40000.00));
		list.add(new Employee(4,"emp4","abc4",24000.00));
		list.add(new Employee(5,"emp5","abc5",28000.00));
		System.out.println("Initial List retrieved using forEach:");
		list.forEach(x->{
			System.out.println(x.getId()+" "+x.getName()+" "+x.getAddress()+" "+x.getSalary());
			});
		Collections.sort(list,Employee::compareBySal);
		System.out.println("Sorted List based on salaries:");
		list.forEach(x->{
			System.out.println(x.getId()+" "+x.getName()+" "+x.getAddress()+" "+x.getSalary());
			});
	}
}
