import java.io.*;

public class MyClassWithLambda{

	
	public static void main(String args[])throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter a string to count no. of words");
		String s=br.readLine();
		WordCount c=(String str)-> {
			int n=0;
			for(int i=0;i<str.length();i++)
			{
				if(str.charAt(i)==' ') 
				{
					n++;
				}
			}
			return n+1;
		};
		System.out.println(c.count(s));
	}

}
