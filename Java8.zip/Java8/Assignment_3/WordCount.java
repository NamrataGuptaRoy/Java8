
public interface WordCount {
public int count(String str);
}
