import java.util.*;
import java.util.stream.Collectors;
public class StringsAPI {
	public static void main(String args[])
	{
		List<String> strings = Arrays.asList("abcd","","","Indians","America","hi","good","","Great");
     System.out.println("List of string objects: " +strings);
	long count=0;
	List<String> str=new ArrayList<String>();
     
     count = strings.stream().filter(string -> string.length()>5).count();
     System.out.println("No. of strings with length>5: " + count);
     count = strings.stream().filter(string->string.isEmpty()).count();
     System.out.println("No. of empty strings: " + count);
     str = strings.stream().filter(string ->!string.isEmpty()).collect(Collectors.toList());
     System.out.println("New list without empty strings: " + str);
	}	
}
